var myApp=angular.module('myApp',['ngMessages']);

myApp.controller('mainController',function(){

});